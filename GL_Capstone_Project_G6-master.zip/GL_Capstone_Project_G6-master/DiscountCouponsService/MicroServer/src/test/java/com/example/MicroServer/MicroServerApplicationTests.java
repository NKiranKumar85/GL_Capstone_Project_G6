package com.example.MicroServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
